//
//  MenuList.swift
//  LittleLemon
//
//  Created by Yaroslav Yurev on 8/31/23.
//

import Foundation

struct MenuList: Decodable {
    
    let menu: Array<MenuItem>
    
}
